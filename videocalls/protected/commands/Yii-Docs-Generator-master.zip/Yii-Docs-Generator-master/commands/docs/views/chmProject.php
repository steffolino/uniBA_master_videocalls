[OPTIONS]
Binary TOC=Yes
Compatibility=1.1 or later
Compiled File=manual.chm
Contents File=manual.hhc
Default Window=main
Default Topic=index.html
Display compile progress=Yes
Error log file=_errorlog.txt
Full-text search=Yes
Language=0x409 English (United States)
Title=Yii Framework v<?php echo Yii::getVersion(); ?> Class Reference
Binary Index=Yes
Index file=manual.hhk
Default Font=
Auto Index=Yes
Create CHI file=No
Full text search stop list file=
Display compile notes=Yes

[WINDOWS]
main="Yii Framework v<?php echo Yii::getVersion(); ?> Class Reference","manual.hhc","manual.hhk","index.html","index.html",,,,,0x63520,250,0x104e,[10,10,900,700],0xb0000,,,,,,0
